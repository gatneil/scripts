# pass credentials from template to scripts
echo "" > credentials.py
echo "username = '$1'" >> credentials.py
echo "password = '$2'" >> credentials.py

cd mysql-connector-python-2.1.3
python setup.py install
cd ..

ps aux | grep apt > apt.txt
ps aux | grep dpkg > dpkg.txt

n=0
until [ $n -ge 5 ]
do
    apt-get install -y nginx python-flask && break  # substitute your command here
    n=$[$n+1]
    sleep 15
done

cp nginx.conf /etc/nginx
service restart nginx

python create_db.py
python server.py > serverOut.txt 2> serverErr.txt &
python gen_substitutes_from_db.py > genOut.txt 2> genErr.txt &
