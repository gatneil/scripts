# pass credentials from template to scripts
echo "" > credentials.py
echo "username = '$1'" >> credentials.py
echo "password = '$2'" >> credentials.py

# install necessary components from source
cd mysql-connector-python-2.1.3
python setup.py install
cd ..

# install necessary components from apt
# can have temporary issues, so wrapped in an infinite loop
while true
do
    apt-get -y update && apt-get -y dist-upgrade && apt-get install -y nginx python-flask && break
    sleep 15
done

# set up nginx for serving static files
# not scrictly necessary but improves image load time
cp nginx.conf /etc/nginx
service restart nginx

# initialize db for parseling out work
python create_db.py

# start flask server for handling web requests
python server.py > serverOut.txt 2> serverErr.txt &

# continuously poll the db for finished work
# put such work in the right place for nginx to serve
python gen_substitutes_from_db.py > genOut.txt 2> genErr.txt &
