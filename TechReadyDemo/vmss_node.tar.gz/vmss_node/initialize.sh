# pass credentials from template to scripts
echo "" > credentials.py
echo "username = '$1'" >> credentials.py
echo "password = '$2'" >> credentials.py

# install necessary components
cd pypng-master
python setup.py install
cd ..

cd mysql-connector-python-2.1.3
python setup.py install
cd ..

ps aux | grep apt > apt.txt
ps aux | grep dpkg > dpkg.txt

#apt-get install -y python-numpy
n=0
until [ $n -ge 5 ]
do
    apt-get update && apt-get dist-upgrade && apt-get install -y python-numpy && break  # substitute your command here
    n=$[$n+1]
    sleep 15
done

python do_work.py > stdout.txt 2> stderr.txt &
