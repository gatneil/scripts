# pass credentials from template to scripts
echo "" > credentials.py
echo "username = '$1'" >> credentials.py
echo "password = '$2'" >> credentials.py

# install necessary components
cd pypng-master
python setup.py install
cd ..

cd mysql-connector-python-2.1.3
python setup.py install
cd ..

apt-get install python-numpy

python do_work.py > stdout.txt 2> stderr.txt &
