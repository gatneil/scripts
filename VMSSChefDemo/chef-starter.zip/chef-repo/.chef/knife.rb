# See https://docs.chef.io/azure_portal.html#azure-marketplace/config_rb_knife.html for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "azure"
client_key               "#{current_dir}/azure.pem"
validation_client_name   "azure-validator"
validation_key           "#{current_dir}/azure-validator.pem"
chef_server_url          "https://server.1zr2ys4y4faurmjgwxh5fsqgtc.dx.internal.cloudapp.net/organizations/azure"
cookbook_path            ["#{current_dir}/../cookbooks"]
